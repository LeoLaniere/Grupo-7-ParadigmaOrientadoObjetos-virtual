package TareaIntegradora2;

public class Omnibus extends Vehiculo{
    private int cantidadPasajeros;

    public Omnibus(String patente, double nivelCombustible, int cantidadPasajeros) {
        super(patente, nivelCombustible);
        this.cantidadPasajeros = cantidadPasajeros;
    }

    @Override
    public String acelerar() {
        if(nivelCombustible > 5){
            if (cantidadPasajeros > 0 && cantidadPasajeros <= 10) {
                nivelCombustible -= 5;
            }
            if (cantidadPasajeros > 10 && cantidadPasajeros <=20 && nivelCombustible > 10){
                nivelCombustible -= 10;
            }
            if(cantidadPasajeros > 20 && nivelCombustible > 15){
                nivelCombustible -= 15;
            }
        }else{
            return "No se puede acelerar por la falta combustible";
        }
        return "Omnibus acelerado";
    }
    public int getCantidadPasajeros() {
        return cantidadPasajeros;
    }

}
