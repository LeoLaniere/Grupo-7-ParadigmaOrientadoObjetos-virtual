package TareaIntegradora2;

public class Vehiculo {
    protected String patente;
    protected double nivelCombustible; /* Admite que las subclases accedan directamente
                                        mantiene encapsulamiento hacia el exterior */
    private static int cantidadVehiculos = 0;


    public Vehiculo(String patente, double nivelCombustible) {
        this.patente = patente;
        this.nivelCombustible = 100;
        cantidadVehiculos++;
    }
    public String acelerar(){
        nivelCombustible = nivelCombustible - 5;
         return "Vehículo acelerando. Combustible restante: " + nivelCombustible;
    }
    public static int getCantidadVehiculos() {
        return cantidadVehiculos;
    }
    public double getNivelCombustible(){
        return nivelCombustible;
    }
}
