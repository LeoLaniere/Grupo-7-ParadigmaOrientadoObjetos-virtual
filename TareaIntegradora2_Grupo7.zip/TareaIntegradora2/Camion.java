package TareaIntegradora2;

public class Camion extends Vehiculo{
    private double capacidadCarga;


    public Camion(String patente, double nivelCombustible, double capacidadCarga) {
        super(patente, nivelCombustible);
        this.capacidadCarga = capacidadCarga;
    }

    @Override
    public String acelerar() {
        if(nivelCombustible > 20){
            if (capacidadCarga > 50 && capacidadCarga < 150){
                nivelCombustible -= 15;
            }
            if (capacidadCarga > 150 && capacidadCarga < 250){
                nivelCombustible -= 25;
            }
            if (capacidadCarga > 250){
                nivelCombustible -= 50;
            }
        } else {
            return "El camion no tiene suficiente combustible";
        }
        return "Camion acelerado";
    }

    public double getCapacidadCarga(){
        return capacidadCarga;
    }

}
